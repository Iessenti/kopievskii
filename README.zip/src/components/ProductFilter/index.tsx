import {  useState } from 'react'

import './styles.sass'

import { DropdownArrowIcon, SmallWhiteCrossIcon } from '../../icons'

export const ProductFilter = () => {

    const [openedList, setOpenedList] = useState<string>('')
    const [choosenCategory, setChoosenCategory] = useState<string>('all')
    const [isSecondRowShowed, setIsSecondRowShowed] = useState<boolean>(false)

    const toggleOpenedList = (type: string) => {
        if (type == openedList) {
            setOpenedList('')
        } else {
            setOpenedList(type)
        }
    }

    const toggleIsSecondRowShowed = () => {
        if (isSecondRowShowed) {
            setIsSecondRowShowed(false)
        } else {
            setIsSecondRowShowed(true)
        }
    }

    return (
        <div className='product-filter-wrapper'>
            
            <div className='product-filter-wrapper__first-row-wrapper'>
                <div className='dropdown-wrapper'>
                    <div 
                        className='dropdown-wrapper__title' 
                        onClick={ () => toggleOpenedList('date')}
                    >  
                        Recently Added
                        <div className={(openedList == 'date') ? 'reversedArrow' : ''}>
                            <DropdownArrowIcon/>
                        </div>
                    </div>

                    {
                        (openedList == 'date')
                        ?
                        <div className='dropdown-fading-wrapper'>
                            <div>selec</div>
                            <div>selec</div>
                            <div>selec</div>
                            <div>selec</div>
                        </div>
                        :
                        <></>
                    }

                </div>
                
                <div className='panel-category-wrapper'>
                    <div
                        className={ (choosenCategory == 'all') ? 'selected-category-panel' : ''}
                        onClick={ () => setChoosenCategory('all')}
                    >All items</div>

                    <div
                        className={ (choosenCategory == 'art') ? 'selected-category-panel' : ''}
                        onClick={ () => setChoosenCategory('art')}                
                    >Art</div>

                    <div
                        className={ (choosenCategory == 'tshirt') ? 'selected-category-panel' : ''}
                        onClick={ () => setChoosenCategory('tshirt')}                
                    >T-Shirt</div>

                    <div
                        className={ (choosenCategory == 'nftcard') ? 'selected-category-panel' : ''}
                        onClick={ () => setChoosenCategory('nftcard')}                
                    >NFT Card</div>

                    <div
                        className={ (choosenCategory == 'socs') ? 'selected-category-panel' : ''}
                        onClick={ () => setChoosenCategory('socs')}              
                    >Socs</div>

                </div>

                <div className='filter-button' onClick={ () => toggleIsSecondRowShowed()}>
                    Filter { isSecondRowShowed ? <SmallWhiteCrossIcon/> : <></> }
                </div>

            </div>


            <div className='divider'></div>
                    
            <div className='product-filter-wrapper__second-row-wrapper'>
            <div className='dropdown-wrapper'>
                    <span>NETWORK</span>

                    <div 
                        className='dropdown-wrapper__title' 
                        onClick={ () => toggleOpenedList('net')}
                    >  
                        All 
                        <div className={(openedList == 'net') ? 'reversedArrow' : ''}>
                            <DropdownArrowIcon/>
                        </div>
                    </div>

                    {
                        (openedList == 'net')
                        ?
                        <div className='dropdown-fading-wrapper'>
                            <div>selec</div>
                            <div>selec</div>
                            <div>selec</div>
                            <div>selec</div>
                        </div>
                        :
                        <></>
                    }

                </div>
                <div className='dropdown-wrapper'>
                    <span>PROJECT</span>
                    
                    <div 
                        className='dropdown-wrapper__title' 
                        onClick={ () => toggleOpenedList('proj')}
                    >  
                        All 
                        <div className={(openedList == 'proj') ? 'reversedArrow' : ''}>
                            <DropdownArrowIcon/>
                        </div>
                    </div>

                    {
                        (openedList == 'proj')
                        ?
                        <div className='dropdown-fading-wrapper'>
                            <div>selec</div>
                            <div>selec</div>
                            <div>selec</div>
                            <div>selec</div>
                        </div>
                        :
                        <></>
                    }

                </div>
                <div className='dropdown-wrapper'>
                    <span>LAUNCH</span>

                    <div 
                        className='dropdown-wrapper__title' 
                        onClick={ () => toggleOpenedList('launch')}
                    >  
                        All 
                        <div className={(openedList == 'launch') ? 'reversedArrow' : ''}>
                            <DropdownArrowIcon/>
                        </div>
                    </div>

                    {
                        (openedList == 'launch')
                        ?
                        <div className='dropdown-fading-wrapper'>
                            <div>selec</div>
                            <div>selec</div>
                            <div>selec</div>
                            <div>selec</div>
                        </div>
                        :
                        <></>
                    }

                </div>
            </div>
        </div>
    )
}