export const data = [
    {
        id: '234',
        price: '0.755 POLY',
        count: '100',
        countLeft: '19',
        photoUrl: '',
        desc: 'This site is operated by Amalgamated Token Services Inc. through its wholly-owned subsidiary, Pielabs Services, LLC (together, “Pielabs”), which is not a registered broker-dealer. Pielabs does not give investment advice, endorsement, analysis or recommendations with respect to any securities or provide legal or tax advice.'
    },
    {
        id: '234',
        price: '0.755 POLY',
        count: '100',
        countLeft: '19',
        photoUrl: '',
        desc: 'This site is operated by Amalgamated Token Services Inc. through its wholly-owned subsidiary, Pielabs Services, LLC (together, “Pielabs”), which is not a registered broker-dealer. Pielabs does not give investment advice, endorsement, analysis or recommendations with respect to any securities or provide legal or tax advice.'
    },
    {
        id: '234',
        price: '0.755 POLY',
        count: '100',
        countLeft: '19',
        photoUrl: '',
        desc: 'This site is operated by Amalgamated Token Services Inc. through its wholly-owned subsidiary, Pielabs Services, LLC (together, “Pielabs”), which is not a registered broker-dealer. Pielabs does not give investment advice, endorsement, analysis or recommendations with respect to any securities or provide legal or tax advice.'
    },
    {
        id: '234',
        price: '0.755 POLY',
        count: '100',
        countLeft: '19',
        photoUrl: '',
        desc: 'This site is operated by Amalgamated Token Services Inc. through its wholly-owned subsidiary, Pielabs Services, LLC (together, “Pielabs”), which is not a registered broker-dealer. Pielabs does not give investment advice, endorsement, analysis or recommendations with respect to any securities or provide legal or tax advice.'
    },
    {
        id: '234',
        price: '0.755 POLY',
        count: '100',
        countLeft: '19',
        photoUrl: '',
        desc: 'This site is operated by Amalgamated Token Services Inc. through its wholly-owned subsidiary, Pielabs Services, LLC (together, “Pielabs”), which is not a registered broker-dealer. Pielabs does not give investment advice, endorsement, analysis or recommendations with respect to any securities or provide legal or tax advice.'
    },
    {
        id: '234',
        price: '0.755 POLY',
        count: '100',
        countLeft: '19',
        photoUrl: '',
        desc: 'This site is operated by Amalgamated Token Services Inc. through its wholly-owned subsidiary, Pielabs Services, LLC (together, “Pielabs”), which is not a registered broker-dealer. Pielabs does not give investment advice, endorsement, analysis or recommendations with respect to any securities or provide legal or tax advice.'
    },
]